<?php $__env->startSection('content'); ?>
<section>
  <div class="container">
      <h1>Edit Profile</h1>
    	<hr>
  	<div class="row">
      <div class="col-md-3">
        <div class="text-center">
          <img src="//placehold.it/200" class="avatar img-circle" alt="avatar">
        </div>
      </div>
        <!-- left column -->
        <!-- edit form column -->
        <div class="col-md-9 personal-info">
          <div class="alert alert-info alert-dismissable">
            <a class="panel-close close" data-dismiss="alert">×</a>
            <i class="fa fa-coffee"></i>
            This is an <strong>.alert</strong>. Use this to show important messages to the user.
          </div>
          <h3>Change Password</h3>

          <form class="form-horizontal" role="form">
            <div class="form-group">
              <label class="col-md-3 control-label">Current Password:</label>
              <div class="col-md-8">
                <input class="form-control" type="password" value="11111122333">
              </div>
            </div>
            <div class="form-group">
              <label class="col-md-3 control-label">New Password:</label>
              <div class="col-md-8">
                <input class="form-control" type="password" value="11111122333">
              </div>
            </div>
            <div class="form-group">
              <label class="col-md-3 control-label">Confirm password:</label>
              <div class="col-md-8">
                <input class="form-control" type="password" value="11111122333">
              </div>
            </div>
            <div class="form-group">
              <label class="col-md-3 control-label"></label>
              <div class="col-md-8">
                <input type="button" class="btn btn-primary" value="Save Changes">
                <span></span>
                <input type="reset" class="btn btn-default" value="Cancel">
              </div>
            </div>
          </form>
        </div>
    </div>
  </div>
  <hr>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lopez Mining\Desktop\refereME\resources\views/changePassword.blade.php ENDPATH**/ ?>