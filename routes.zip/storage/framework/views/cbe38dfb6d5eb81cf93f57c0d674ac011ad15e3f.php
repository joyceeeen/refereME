<?php $__env->startSection('content'); ?>
<section class="pb-5">
  <div class="container">
    <h5 class="section-title h1">Referred Patient Details</h5>
    <div class="card">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-4">
            <div class="form-group">
              <h4 class="text-primary pb-2"><b>Last Name:</b></h4>
              <?php echo e($referral->patient->lastname); ?>

            </div>
          </div>
          <div class="col-lg-4">
            <div class="form-group">
              <h5 class="text-primary pb-2"><b>First Name:</b></h5>
              <?php echo e($referral->patient->firstname); ?>

            </div>
          </div>
          <div class="col-lg-4">
            <div class="form-group">
              <h5 class="text-primary pb-2"><b>Middle Name:</b></h5>
              <?php echo e($referral->patient->middlename); ?>


            </div>
          </div>
        </div>
        <div class="row">

          <div class="col-lg-4">
            <div class="form-group">
              <h5 class="text-primary pb-2"><b>Date of Birth:</b></h5>
              <?php echo e($referral->patient->birthday); ?>

            </div>
          </div>
          <div class="col-lg-4">
            <div class="form-group">
              <h5 class="text-primary pb-2"><b>Contact Number:</b></h5>
              <?php echo e($referral->patient->contact_number); ?>

            </div>
          </div>
          <div class="col-lg-4">
            <div class="form-group">
              <h5 class="text-primary pb-2"><b>Email Address:</b></h5>
              <?php echo e($referral->patient->email_address); ?>

            </div>
          </div>
          <div class="col-lg-4">
            <h5 class="text-primary pb-2"><b>Sex:</b></h5>
            <?php echo e($referral->patient->gender); ?>

          </div>
        </div>
        <hr>
        <div class="text-justify">
          <h3 class="text-primary pb-2"><b>Reason for Referral</b></h3>
          <h5 class="text-primary pb-2"><b>Report:</b></h5>
          <?php echo e($referral->report); ?>

        </div>
        <hr>

        <div class="text-justify">
          <h5 class="text-primary pb-2"><b>Attachments:</b></h5>
           <ul>
             <?php $__currentLoopData = $referral->reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><a href="/attachment/<?php echo e($report->id); ?>">Attachment #<?php echo e($key + 1); ?></a></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
          <?php $__currentLoopData = $referral->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="nav-item">
            <a class="nav-link <?php echo e($key == 0 ? 'active' : ''); ?>" id="<?php echo e($test->reference->view); ?>-tab" data-toggle="tab" href="#<?php echo e($test->reference->view); ?>" role="tab" aria-controls="cbc" aria-selected="true"><?php echo e($test->reference->report); ?></a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
        <div class="tab-content" id="myTabContent">
          <?php $__currentLoopData = $referral->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="tab-pane fade show <?php echo e($key == 0 ? 'active' : ''); ?> pt-3" id="<?php echo e($result->reference->view); ?>" role="tabpanel" aria-labelledby="<?php echo e($result->reference->view); ?>-tab">
            <?php echo $__env->make('partials.'.$result->reference->view, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lopez Mining\Desktop\refereME\resources\views/success-referral.blade.php ENDPATH**/ ?>