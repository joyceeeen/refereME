<?php $__env->startSection('content'); ?>
<section class="pb-5">
  <div class="container-fluid" style="padding-left:8rem;padding-right:8rem;">

    <div class="row pb-5">
      <div class="col-lg-12">
        <h5 class="section-title h1">My Referrals</h5>
        <div class="table-responsive">
          <table class="table table-bordered">
          <thead class="thead-dark">
            <tr>
              <th scope="col">Status</th>
              <th scope="col">Last Name</th>
              <th scope="col">First Name</th>
              <th scope="col">Middle Name</th>
              <th scope="col">Date of Birth</th>
              <th scope="col">Contact #</th>
              <th scope="col">View More</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $clients->referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="my-referrals-row" class="status-<?php echo e($client->status); ?>">
              <td><?php echo e($client->status); ?></td>
              <td><?php echo e($client->patient->lastname); ?></td>
              <td><?php echo e($client->patient->firstname); ?></td>
              <td><?php echo e($client->patient->middlename); ?></td>
              <td><?php echo e($client->patient->birthday); ?></td>
              <td><?php echo e($client->patient->contact_number); ?></td>
              <td><a href="#" data-toggle="modal" class="patientDetailsModal"  data-id="<?php echo e($client->id); ?>" >View More</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
        </div>
      </div>
    </div>

  </div>
</section>

<div class="modal fade bd-example-modal-lg" id="patientDetailsModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myLargeModalLabel"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lopez Mining\Desktop\refereME\resources\views/my-referrals.blade.php ENDPATH**/ ?>