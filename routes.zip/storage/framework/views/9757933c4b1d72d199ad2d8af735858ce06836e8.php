<?php $__env->startSection('content'); ?>
<section class="pb-5">
  <div class="container">
    <h5 class="section-title h1">Refer Patient</h5>
    <div class="card">
      <div class="card-body">
        <div class="text-center">
          <p><img class="imgRefer img-fluid" src="<?php echo e($doctor->avatar ? '/'.$doctor->avatar : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAAAAAA6fptVAAAACklEQVQI12O4AQAA2gDZumdc2gAAAABJRU5ErkJggg=='); ?>" alt="card image"></p>
          <h4 class="card-title mb-0 font-weight-bold"><?php echo e($doctor->is_hospital ? $doctor->hospital_name : $doctor->name); ?></h4>
          <h5 class="card-title mb-3"><?php echo e($doctor->is_hospital ? '' : $doctor->specialization); ?></h5>
          <p class="card-text font-weight-bold mb-0 text-dark"><?php echo e($doctor->address); ?></p>
          <p class="card-text text-dark"><?php echo e($doctor->contact_number); ?></p>
        </div>
        <hr>
        <form method="post" action="<?php echo e(route('refer.store')); ?>" enctype="multipart/form-data">
        <?php echo $__env->make('partials.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-lg-4">
              <div class="form-group">
                <h4 class="text-primary pb-2"><b>Last Name:</b></h4>
                <input type="text" name="lastname" required class="form-control" placeholder="Aridedon" id="lName">
              </div>
            </div>
            <div class="col-lg-4">
              <div class="form-group">
                <h5 class="text-primary pb-2"><b>First Name:</b></h5>
                <input type="text"  name="firstname" required  class="form-control" placeholder="Yancy" id="fName">
              </div>
            </div>
            <div class="col-lg-4">
              <div class="form-group">
                <h5 class="text-primary pb-2"><b>Middle Name:</b></h5>
                <input type="text" name="middlename" required class="form-control" placeholder="Yans" id="mName">
              </div>
            </div>
          </div>
          <div class="row">

            <div class="col-lg-4">
              <div class="form-group">
                <h5 class="text-primary pb-2"><b>Date of Birth:</b></h5>
                <input type="date" name="birthday" required class="form-control" id="fName">
              </div>
            </div>
            <div class="col-lg-4">
              <div class="form-group">
                <h5 class="text-primary pb-2"><b>Contact Number:</b></h5>
                <input type="text" name="contact_number" required class="form-control" id="contactNo" placeholder="09172390989">
              </div>
            </div>
            <div class="col-lg-4">
              <div class="form-group">
                <h5 class="text-primary pb-2"><b>Email Address:</b></h5>
                <input type="email" name="email_address" required class="form-control" id="emailAd" placeholder="test@email.com">
              </div>
            </div>
            <div class="col-lg-4">
              <h5 class="text-primary pb-2"><b>Sex:</b></h5>
              <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" class="custom-control-input" id="customRadio" name="gender" value="0" checked>
                <label class="custom-control-label" for="customRadio">Male</label>
              </div>
              <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" class="custom-control-input" id="customRadio2" name="gender" value="1">
                <label class="custom-control-label" for="customRadio2">Female</label>
              </div>
            </div>
          </div>
          <hr>
          <div class="text-justify">
            <h3 class="text-primary pb-2"><b>Reason for Referral</b></h3>
            <h5 class="text-primary pb-2"><b>Report:</b></h5>
            <textarea name="report" rows="8" required cols="80" class="form-control"></textarea>
          </div>
          <input type="hidden" name="doctor_id" value="<?php echo e(request()->id); ?>"/>
          <hr>
          <!-- Button trigger modal -->
          <div class="row">
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="checkbox col-lg-4">
              <label><input name="reports[]" type="checkbox" value="<?php echo e($report->id); ?>"> <?php echo e($report->report); ?></label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>

          <div class="text-justify">
            <h5 class="text-primary pb-2"><b>Attachments:</b></h5>
            <div class="custom-file">
              <input name="attachments[]" multiple type="file" accept="image/*" class="custom-file-input" id="customFile">
              <label class="custom-file-label" for="customFile">Choose file</label>
            </div>
          </div>
          <div class="pt-3">
            <center>
              <button type="submit" name="button" class="btn btn-primary">Submit Referral</button>
            </center>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lopez Mining\Desktop\refereME\resources\views/refer.blade.php ENDPATH**/ ?>