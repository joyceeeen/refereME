<?php $__env->startSection('content'); ?>
<section>
  <div class="container">
      <h1>Edit Schedule</h1>
    	<hr>
  	<div class="row">
        <!-- left column -->
        <div class="col-md-3">
          <div class="text-center">
            <img src="<?php echo e($user->avatar ? $user->avatar : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAAAAAA6fptVAAAACklEQVQI12O4AQAA2gDZumdc2gAAAABJRU5ErkJggg=='); ?>" width="150px" class="img-thumbnail" alt="avatar">
          </div>
        </div>

        <!-- edit form column -->
        <div class="col-md-9 personal-info">
          <h3>Schedule</h3>
          <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" id="monday-tab" data-toggle="tab" href="#monday" role="tab" aria-controls="monday" aria-selected="true">Monday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="tuesday-tab" data-toggle="tab" href="#tuesday" role="tab" aria-controls="tuesday" aria-selected="false">Tuesday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="wednesday-tab" data-toggle="tab" href="#wednesday" role="tab" aria-controls="wednesday" aria-selected="false">Wednesday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="thursday-tab" data-toggle="tab" href="#thursday" role="tab" aria-controls="thursday" aria-selected="true">Thursday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="friday-tab" data-toggle="tab" href="#friday" role="tab" aria-controls="friday" aria-selected="false">Friday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="saturday-tab" data-toggle="tab" href="#saturday" role="tab" aria-controls="saturday" aria-selected="false">Saturday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="sunday-tab" data-toggle="tab" href="#sunday" role="tab" aria-controls="sunday" aria-selected="false">Sunday</a>
            </li>
          </ul>
          <div class="tab-content pt-4" id="myTabContent">
            <?php echo $__env->make('partials.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="tab-pane fade show active" id="monday" role="tabpanel" aria-labelledby="monday-tab">
              <?php if(isset($schedule) && $sched1): ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.update',$user->id)); ?>" role="form">
                <?php echo method_field('PUT'); ?>
              <?php else: ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.store')); ?>" role="form">

              <?php endif; ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="day" value="1"/>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input name="hospital" value="<?php echo e($sched1 ? $sched1->hospital: ''); ?>" class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input name="address" value="<?php echo e($sched1 ? $sched1->address : ''); ?>"  class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="schedule" name="name" rows="8" cols="80" class="form-control" ><?php echo e($sched1 ? $sched1->schedule : ''); ?> </textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input name="contact_number" class="form-control" type="text" value="<?php echo e($sched1 ? $sched1->contact_number : ''); ?>" >
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="submit" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="tuesday" role="tabpanel" aria-labelledby="tuesday-tab">
              <?php if(isset($schedule) && $sched2): ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.update',$user->id)); ?>" role="form">
                <?php echo method_field('PUT'); ?>
              <?php else: ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.store')); ?>" role="form">
              <?php endif; ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="day" value="2"/>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input name="hospital" value="<?php echo e($sched2 ? $sched2->hospital : ''); ?>" class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input name="address" value="<?php echo e($sched2 ? $sched2->address : ''); ?>"  class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="schedule" name="name" rows="8" cols="80" class="form-control" ><?php echo e($sched2 ? $sched2->schedule : ''); ?> </textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input name="contact_number" class="form-control" type="text" value="<?php echo e($sched2 ? $sched2->contact_number :''); ?>" >
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="submit" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="wednesday" role="tabpanel" aria-labelledby="wednesday-tab">
              <?php if(isset($schedule) && $sched3): ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.update',$user->id)); ?>" role="form">
                <?php echo method_field('PUT'); ?>
              <?php else: ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.store')); ?>" role="form">
              <?php endif; ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="day" value="3"/>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input name="hospital" value="<?php echo e($sched3 ? $sched3->hospital :''); ?>" class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input name="address" value="<?php echo e($sched3 ? $sched3->address : ''); ?>"  class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="schedule" name="name" rows="8" cols="80" class="form-control" ><?php echo e($sched3 ? $sched3->schedule : ''); ?> </textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input name="contact_number" class="form-control" type="text" value="<?php echo e($sched3 ? $sched3->contact_number :''); ?>" >
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="submit" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="thursday" role="tabpanel" aria-labelledby="thursday-tab">
              <?php if(isset($schedule) && $sched4): ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.update',$user->id)); ?>" role="form">
                <?php echo method_field('PUT'); ?>
              <?php else: ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.store')); ?>" role="form">
              <?php endif; ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="day" value="4"/>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input name="hospital" value="<?php echo e($sched4 ? $sched4->hospital : ''); ?>" class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input name="address" value="<?php echo e($sched4 ? $sched4->address : ''); ?>"  class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="schedule" name="name" rows="8" cols="80" class="form-control"><?php echo e($sched4 ? $sched4->schedule : ''); ?></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input name="contact_number" class="form-control" type="text" value="<?php echo e($sched4 ? $sched4->contact_number : ''); ?>" >
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="submit" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="friday" role="tabpanel" aria-labelledby="friday-tab">
              <?php if(isset($schedule) && $sched5): ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.update',$user->id)); ?>" role="form">
                <?php echo method_field('PUT'); ?>
              <?php else: ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.store')); ?>" role="form">
              <?php endif; ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="day" value="5"/>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input name="hospital" value="<?php echo e($sched5 ? $sched5->hospital : ''); ?>" class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input name="address" value="<?php echo e($sched5 ? $sched5->address : ''); ?>"  class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="schedule" name="name" rows="8" cols="80" class="form-control"><?php echo e($sched5 ? $sched5->schedule :''); ?> </textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input name="contact_number" class="form-control" type="text" value="<?php echo e($sched5 ? $sched5->contact_number : ''); ?>" >
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="submit" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="saturday" role="tabpanel" aria-labelledby="saturday-tab">
              <?php if(isset($schedule) && $sched6): ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.update',$user->id)); ?>" role="form">
                <?php echo method_field('PUT'); ?>
              <?php else: ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.store')); ?>" role="form">
              <?php endif; ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="day" value="6"/>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input name="hospital" class="form-control" value="<?php echo e($sched6 ? $sched6->hospital: ''); ?>" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input name="address" value="<?php echo e($sched6 ? $sched6->address : ''); ?>" class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="schedule" name="name" rows="8" cols="80" class="form-control" ><?php echo e($sched6 ? $sched6->schedule : ''); ?></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input name="contact_number" value="<?php echo e($sched6 ? $sched6->contact_number : ''); ?>" class="form-control" type="text" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="submit" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="sunday" role="tabpanel" aria-labelledby="sunday-tab">
              <?php if(isset($schedule) && $sched7): ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.update',$user->id)); ?>" role="form">
                <?php echo method_field('PUT'); ?>
              <?php else: ?>
              <form class="form-horizontal" method="post" action="<?php echo e(route('schedule.store')); ?>" role="form">
              <?php endif; ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="day" value="7"/>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input name="hospital" value="<?php echo e($sched7 ? $sched7->hospital : ''); ?>" class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input name="address"  value="<?php echo e($sched7 ? $sched7->address : ''); ?>"  class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="schedule" name="name" rows="8" cols="80" class="form-control" ><?php echo e($sched7 ? $sched7->schedule : ''); ?></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input name="contact_number" class="form-control" type="text" value="<?php echo e($sched7 ? $sched7->contact_number : ''); ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="submit" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
          </div>

        </div>
    </div>
  </div>
  <hr>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lopez Mining\Desktop\refereME\resources\views/user/schedule.blade.php ENDPATH**/ ?>