<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row align-items-center justify-content-center">

    <div class="col-12 col-md-7 col-lg-6 col-xl-8 d-none d-lg-block  no-padding">

      <!-- Image -->
      <div class="bg-cover vh-100 mt-n1 mr-n3" style="background-image: url('https://images.pexels.com/photos/1282308/pexels-photo-1282308.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=2&h=650&w=940');"></div>

    </div>
    <div class="col-12 col-md-5 col-lg-4" style="padding:60px">

      <!-- Heading -->
      <h1 class="display-4 text-center mb-3">
        Register
      </h1>
      <!-- Subheading -->
      <p class="text-muted text-center mb-5">
        Patient Referral System
      </p>
      <!-- Form -->
      <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
          <select name="is_hospital" class="form-control" id="exampleFormControlSelect1">
            <option value="0">Doctor</option>
            <option value="1">Hospital</option>
          </select>

          <?php if ($errors->has('is_hospital')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('is_hospital'); ?>
          <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
          </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <!-- Email address -->
        <div class="form-group">

          <!-- Label -->
          <label><?php echo e(__('First Name')); ?></label>
          <input id="firstname" type="text" class="form-control <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="firstname" value="<?php echo e(old('firstname')); ?>" required>

          <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?>
          <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
          </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        </div>

        <div class="form-group">

          <!-- Label -->
          <label><?php echo e(__('Last Name')); ?></label>
          <input id="lastname" type="text" class="form-control <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="lastname" value="<?php echo e(old('lastname')); ?>" required>

          <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?>
          <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
          </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        </div>

        <!-- Email address -->
        <div class="form-group">

          <!-- Label -->
          <label><?php echo e(__('E-Mail Address')); ?></label>
          <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required >

          <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
          <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
          </span>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        </div>

        <!-- Password -->
        <div class="form-group">

          <div class="row">
            <div class="col">

              <!-- Label -->
              <label><?php echo e(__('Password')); ?></label>

            </div>
          </div> <!-- / .row -->

          <!-- Input group -->
          <div class="input-group input-group-merge">

            <!-- Input -->
            <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required >

            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
          </div>
        </div>
        <!-- Confirm Password -->
        <div class="form-group">

          <div class="row">
            <div class="col">

              <!-- Label -->
              <label><?php echo e(__('Confirm Password')); ?></label>

            </div>
          </div> <!-- / .row -->

          <!-- Input group -->
          <div class="input-group input-group-merge">

            <!-- Input -->
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required >
          </div>
        </div>
        <!-- Submit -->
        <button type="submit" class="btn btn-lg btn-block btn-primary mb-3">
          <?php echo e(__('Register')); ?>

        </button>

        <!-- Link -->
        <p class="text-center">
          <small class="text-muted text-center">
            Already have an account? <a href="login">Sign in</a>.
          </small>
        </p>

      </form>

    </div>
  </div> <!-- / .row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lopez Mining\Desktop\refereME\resources\views/auth/register.blade.php ENDPATH**/ ?>