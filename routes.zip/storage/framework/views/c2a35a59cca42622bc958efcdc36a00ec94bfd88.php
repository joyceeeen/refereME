<?php $__env->startSection('content'); ?>
<section>
  <div class="container">
      <h1>Edit Profile</h1>
    	<hr>
  	<div class="row">
        <!-- left column -->
        <div class="col-md-3">
          <div class="text-center">
            <img src="<?php echo e($user->avatar ? $user->avatar : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAAAAAA6fptVAAAACklEQVQI12O4AQAA2gDZumdc2gAAAABJRU5ErkJggg=='); ?>" width="150px" class="img-thumbnail" alt="avatar">
          </div>
        </div>

        <!-- edit form column -->
        <div class="col-md-9 personal-info">
          <h3>Schedule</h3>
          <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" id="monday-tab" data-toggle="tab" href="#monday" role="tab" aria-controls="monday" aria-selected="true">Monday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="tuesday-tab" data-toggle="tab" href="#tuesday" role="tab" aria-controls="tuesday" aria-selected="false">Tuesday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="wednesday-tab" data-toggle="tab" href="#wednesday" role="tab" aria-controls="wednesday" aria-selected="false">Wednesday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="thursday-tab" data-toggle="tab" href="#thursday" role="tab" aria-controls="thursday" aria-selected="true">Thursday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="friday-tab" data-toggle="tab" href="#friday" role="tab" aria-controls="friday" aria-selected="false">Friday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="saturday-tab" data-toggle="tab" href="#saturday" role="tab" aria-controls="saturday" aria-selected="false">Saturday</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="sunday-tab" data-toggle="tab" href="#sunday" role="tab" aria-controls="sunday" aria-selected="false">Sunday</a>
            </li>
          </ul>
          <div class="tab-content pt-4" id="myTabContent">
            <div class="tab-pane fade show active" id="monday" role="tabpanel" aria-labelledby="monday-tab">
              <form class="form-horizontal" role="form">
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="name" rows="8" cols="80" class="form-control" ></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="button" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="tuesday" role="tabpanel" aria-labelledby="tuesday-tab">
              <form class="form-horizontal" role="form">
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="name" rows="8" cols="80" class="form-control" ></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="button" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="wednesday" role="tabpanel" aria-labelledby="wednesday-tab">
              <form class="form-horizontal" role="form">
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="name" rows="8" cols="80" class="form-control" ></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="button" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="thursday" role="tabpanel" aria-labelledby="thursday-tab">
              <form class="form-horizontal" role="form">
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="name" rows="8" cols="80" class="form-control" ></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="button" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="friday" role="tabpanel" aria-labelledby="friday-tab">
              <form class="form-horizontal" role="form">
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="name" rows="8" cols="80" class="form-control" ></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="button" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="saturday" role="tabpanel" aria-labelledby="saturday-tab">
              <form class="form-horizontal" role="form">
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="name" rows="8" cols="80" class="form-control" ></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="button" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
            <div class="tab-pane fade" id="sunday" role="tabpanel" aria-labelledby="sunday-tab">
              <form class="form-horizontal" role="form">
                <div class="form-group">
                  <label class="col-lg-3 control-label">Clinic/Hospital:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Address:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Schedule:</label>
                  <div class="col-lg-8">
                    <textarea name="name" rows="8" cols="80" class="form-control" ></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-lg-3 control-label">Contact Number:</label>
                  <div class="col-lg-8">
                    <input class="form-control" type="text" value="">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-md-3 control-label"></label>
                  <div class="col-md-8">
                    <input type="button" class="btn btn-primary" value="Save Changes">
                    <span></span>
                    <input type="reset" class="btn btn-default" value="Cancel">
                  </div>
                </div>
              </form>
            </div>
          </div>

        </div>
    </div>
  </div>
  <hr>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lopez Mining\Desktop\refereME\resources\views/schedule.blade.php ENDPATH**/ ?>